#define ZINT
#include "umfpack_qsymbolic.c"
