#define DLONG

#include "umf_tuple_lengths.c"
