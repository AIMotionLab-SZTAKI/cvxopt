#define ZLONG

#include "umfpack_free_symbolic.c"
