#define ZLONG

#include "umf_valid_symbolic.c"
