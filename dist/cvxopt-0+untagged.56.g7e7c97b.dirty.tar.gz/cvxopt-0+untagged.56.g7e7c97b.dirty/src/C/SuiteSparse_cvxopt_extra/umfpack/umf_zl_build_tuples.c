#define ZLONG

#include "umf_build_tuples.c"
