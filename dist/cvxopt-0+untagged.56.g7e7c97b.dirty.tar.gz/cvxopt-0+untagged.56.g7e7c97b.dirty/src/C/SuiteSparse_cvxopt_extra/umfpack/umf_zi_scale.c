#define ZINT
#include "umf_scale.c"
