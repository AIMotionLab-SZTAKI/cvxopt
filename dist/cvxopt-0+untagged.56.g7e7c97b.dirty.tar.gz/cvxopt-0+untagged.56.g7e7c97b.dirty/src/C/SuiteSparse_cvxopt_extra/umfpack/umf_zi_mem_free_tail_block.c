#define ZINT
#include "umf_mem_free_tail_block.c"
