#define DLONG

#include "umf_realloc.c"
