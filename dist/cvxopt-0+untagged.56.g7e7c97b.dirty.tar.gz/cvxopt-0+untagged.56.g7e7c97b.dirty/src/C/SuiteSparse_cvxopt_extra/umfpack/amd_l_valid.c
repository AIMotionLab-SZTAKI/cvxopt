#define DLONG

#include "amd_valid.c"
