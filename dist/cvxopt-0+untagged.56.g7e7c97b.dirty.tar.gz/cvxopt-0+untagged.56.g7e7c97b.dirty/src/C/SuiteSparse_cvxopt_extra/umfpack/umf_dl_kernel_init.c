#define DLONG

#include "umf_kernel_init.c"
