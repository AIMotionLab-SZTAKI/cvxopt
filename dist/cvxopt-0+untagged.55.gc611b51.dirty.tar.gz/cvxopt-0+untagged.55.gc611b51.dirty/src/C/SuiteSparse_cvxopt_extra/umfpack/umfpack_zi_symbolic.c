#define ZINT
#include "umfpack_symbolic.c"
