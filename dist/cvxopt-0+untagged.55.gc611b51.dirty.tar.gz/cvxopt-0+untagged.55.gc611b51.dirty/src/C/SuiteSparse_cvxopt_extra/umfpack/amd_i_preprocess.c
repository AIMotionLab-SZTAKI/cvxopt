#define DINT

#include "amd_preprocess.c"
