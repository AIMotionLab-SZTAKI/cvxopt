#define DLONG

#include "umf_symbolic_usage.c"
