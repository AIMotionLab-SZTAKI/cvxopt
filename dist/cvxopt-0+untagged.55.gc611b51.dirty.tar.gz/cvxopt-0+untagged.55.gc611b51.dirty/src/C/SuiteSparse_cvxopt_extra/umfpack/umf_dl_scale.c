#define DLONG

#include "umf_scale.c"
