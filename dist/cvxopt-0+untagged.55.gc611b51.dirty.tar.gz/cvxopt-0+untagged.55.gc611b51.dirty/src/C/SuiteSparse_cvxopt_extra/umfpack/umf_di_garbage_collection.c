#define DINT
#include "umf_garbage_collection.c"
