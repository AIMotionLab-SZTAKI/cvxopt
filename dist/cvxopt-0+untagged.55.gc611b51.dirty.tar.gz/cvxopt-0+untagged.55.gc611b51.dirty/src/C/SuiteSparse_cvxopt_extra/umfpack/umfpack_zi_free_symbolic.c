#define ZINT
#include "umfpack_free_symbolic.c"
